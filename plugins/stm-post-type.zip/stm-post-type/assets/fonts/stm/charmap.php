<?php $icons                                 = array();
$icons['stm']['high-stocks']                 = array(
	'class' => 'high-stocks',
	'tags'  => 'high-stocks',
);
$icons['stm']['board-with-chart']            = array(
	'class' => 'board-with-chart',
	'tags'  => 'board-with-chart',
);
$icons['stm']['business-card']               = array(
	'class' => 'business-card',
	'tags'  => 'business-card',
);
$icons['stm']['world-money']                 = array(
	'class' => 'world-money',
	'tags'  => 'world-money',
);
$icons['stm']['finance-service']             = array(
	'class' => 'finance-service',
	'tags'  => 'finance-service',
);
$icons['stm']['business-strategy']           = array(
	'class' => 'business-strategy',
	'tags'  => 'business-strategy',
);
$icons['stm']['counseling-business']         = array(
	'class' => 'counseling-business',
	'tags'  => 'counseling-business',
);
$icons['stm']['bond-award']                  = array(
	'class' => 'bond-award',
	'tags'  => 'bond-award',
);
$icons['stm']['document-success']            = array(
	'class' => 'document-success',
	'tags'  => 'document-success',
);
$icons['stm']['circuit_big']                 = array(
	'class' => 'circuit_big',
	'tags'  => 'circuit_big',
);
$icons['stm']['circle-notch']                = array(
	'class' => 'circle-notch',
	'tags'  => 'circle-notch',
);
$icons['stm']['contact_email']               = array(
	'class' => 'contact_email',
	'tags'  => 'contact_email',
);
$icons['stm']['contact_phone']               = array(
	'class' => 'contact_phone',
	'tags'  => 'contact_phone',
);
$icons['stm']['contact_pin']                 = array(
	'class' => 'contact_pin',
	'tags'  => 'contact_pin',
);
$icons['stm']['skype']                       = array(
	'class' => 'skype',
	'tags'  => 'skype',
);
$icons['stm']['whatsapp']                    = array(
	'class' => 'whatsapp',
	'tags'  => 'whatsapp',
);
$icons['stm']['email2']                      = array(
	'class' => 'email2',
	'tags'  => 'email2',
);
$icons['stm']['briefcase']                   = array(
	'class' => 'briefcase',
	'tags'  => 'briefcase',
);
$icons['stm']['contact-message']             = array(
	'class' => 'contact-message',
	'tags'  => 'contact-message',
);
$icons['stm']['image_frame']                 = array(
	'class' => 'image_frame',
	'tags'  => 'image_frame',
);
$icons['stm']['linear_circle']               = array(
	'class' => 'linear_circle',
	'tags'  => 'linear_circle',
);
$icons['stm']['linear_r']                    = array(
	'class' => 'linear_r',
	'tags'  => 'linear_r',
);
$icons['stm']['location']                    = array(
	'class' => 'location',
	'tags'  => 'location',
);
$icons['stm']['right-arrow']                 = array(
	'class' => 'right-arrow',
	'tags'  => 'right-arrow',
);
$icons['stm']['tick']                        = array(
	'class' => 'tick',
	'tags'  => 'tick',
);
$icons['stm']['call']                        = array(
	'class' => 'call',
	'tags'  => 'call',
);
$icons['stm']['email']                       = array(
	'class' => 'email',
	'tags'  => 'email',
);
$icons['stm']['time-call']                   = array(
	'class' => 'time-call',
	'tags'  => 'time-call',
);
$icons['stm']['clean-energy']                = array(
	'class' => 'clean-energy',
	'tags'  => 'clean-energy',
);
$icons['stm']['statistics']                  = array(
	'class' => 'statistics',
	'tags'  => 'statistics',
);
$icons['stm']['world']                       = array(
	'class' => 'world',
	'tags'  => 'world',
);
$icons['stm']['worldwide-shipping']          = array(
	'class' => 'worldwide-shipping',
	'tags'  => 'worldwide-shipping',
);
$icons['stm']['audit-assurance']             = array(
	'class' => 'audit-assurance',
	'tags'  => 'audit-assurance',
);
$icons['stm']['financial-services']          = array(
	'class' => 'financial-services',
	'tags'  => 'financial-services',
);
$icons['stm']['strategic-planning']          = array(
	'class' => 'strategic-planning',
	'tags'  => 'strategic-planning',
);
$icons['stm']['online-address']              = array(
	'class' => 'online-address',
	'tags'  => 'online-address',
);
$icons['stm']['online-analytics']            = array(
	'class' => 'online-analytics',
	'tags'  => 'analytics',
);
$icons['stm']['online-calculator']           = array(
	'class' => 'online-calculator',
	'tags'  => 'calculator',
);
$icons['stm']['online-dollar']               = array(
	'class' => 'online-dollar',
	'tags'  => 'dollar',
);
$icons['stm']['online-phone-call']           = array(
	'class' => 'online-phone-call',
	'tags'  => 'phone-call',
);
$icons['stm']['online-plane-big']            = array(
	'class' => 'online-plane-big',
	'tags'  => 'plane-big',
);
$icons['stm']['online-plane']                = array(
	'class' => 'online-plane',
	'tags'  => 'plane',
);
$icons['stm']['online-supermarket']          = array(
	'class' => 'online-supermarket',
	'tags'  => 'supermarket',
);
$icons['stm']['online-work']                 = array(
	'class' => 'online-work',
	'tags'  => 'work',
);
$icons['stm']['glob-pdf']                    = array(
	'class' => 'glob-pdf',
	'tags'  => 'pdf',
);
$icons['stm']['glob-graph']                  = array(
	'class' => 'glob-graph',
	'tags'  => 'graph',
);
$icons['stm']['glob-shield']                 = array(
	'class' => 'glob-shield',
	'tags'  => 'shield',
);
$icons['stm']['glob-building']               = array(
	'class' => 'glob-building',
	'tags'  => 'building',
);
$icons['stm']['glob-play']                   = array(
	'class' => 'glob-play',
	'tags'  => 'play',
);
$icons['stm']['glob-man-user']               = array(
	'class' => 'glob-man-user',
	'tags'  => 'user',
);
$icons['stm']['glob-pie-chart']              = array(
	'class' => 'glob-pie-chart',
	'tags'  => 'chart',
);
$icons['stm']['glob-workers']                = array(
	'class' => 'glob-workers',
	'tags'  => 'people',
);
$icons['stm']['glob-consulting']             = array(
	'class' => 'glob-consulting',
	'tags'  => 'consulting',
);
$icons['stm']['glob-search']                 = array(
	'class' => 'glob-search',
	'tags'  => 'search',
);
$icons['stm']['lnr-arrow-left']              = array(
	'class' => 'lnr-arrow-left',
	'tags'  => 'left',
);
$icons['stm']['lnr-arrow-right']             = array(
	'class' => 'lnr-arrow-right',
	'tags'  => 'right',
);
$icons['stm']['lnr-check']                   = array(
	'class' => 'lnr-check',
	'tags'  => 'check',
);
$icons['stm']['lnr-chevron-left']            = array(
	'class' => 'lnr-chevron-left',
	'tags'  => 'left',
);
$icons['stm']['lnr-chevron-right']           = array(
	'class' => 'lnr-chevron-right',
	'tags'  => 'right',
);
$icons['stm']['lnr-clock']                   = array(
	'class' => 'lnr-clock',
	'tags'  => 'clock',
);
$icons['stm']['lnr-close']                   = array(
	'class' => 'lnr-close',
	'tags'  => 'close',
);
$icons['stm']['lnr-map-pin']                 = array(
	'class' => 'lnr-map-pin',
	'tags'  => 'map',
);
$icons['stm']['lnr-phone']                   = array(
	'class' => 'lnr-phone',
	'tags'  => 'phone',
);
$icons['stm']['lnr-refresh']                 = array(
	'class' => 'lnr-refresh',
	'tags'  => 'refresh',
);
$icons['stm']['lnr-search']                  = array(
	'class' => 'lnr-search',
	'tags'  => 'search',
);
$icons['stm']['ankara-case']                 = array(
	'class' => 'ankara-case',
	'tags'  => 'case',
);
$icons['stm']['ankara-like']                 = array(
	'class' => 'ankara-like',
	'tags'  => 'like',
);
$icons['stm']['ankara-trophy']               = array(
	'class' => 'ankara-trophy',
	'tags'  => 'trophy',
);
$icons['stm']['ankara-user']                 = array(
	'class' => 'ankara-user',
	'tags'  => 'user',
);
$icons['stm']['ankara-money']                = array(
	'class' => 'ankara-money',
	'tags'  => 'money',
);
$icons['stm']['ankara-puzzle']               = array(
	'class' => 'ankara-puzzle',
	'tags'  => 'puzzle',
);
$icons['stm']['ankara-save-money']           = array(
	'class' => 'ankara-save-money',
	'tags'  => 'money',
);
$icons['stm']['ankara-search']               = array(
	'class' => 'ankara-search',
	'tags'  => 'search',
);
$icons['stm']['stockholm-window']            = array(
	'class' => 'stockholm-window',
	'tags'  => 'window',
);
$icons['stm']['career']                      = array(
	'class' => 'career',
	'tags'  => 'career',
);
$icons['stm']['certificate']                 = array(
	'class' => 'certificate',
	'tags'  => 'certificate',
);
$icons['stm']['horn']                        = array(
	'class' => 'horn',
	'tags'  => 'horn',
);
$icons['stm']['award']                       = array(
	'class' => 'award',
	'tags'  => 'award',
);
$icons['stm']['lisbon-like']                 = array(
	'class' => 'lisbon-like',
	'tags'  => 'lisbon-like',
);
$icons['stm']['people']                      = array(
	'class' => 'people',
	'tags'  => 'people',
);
$icons['stm']['suitcase-2']                  = array(
	'class' => 'suitcase-2',
	'tags'  => 'suitcase-2',
);
$icons['stm']['state']                       = array(
	'class' => 'state',
	'tags'  => 'state',
);
$icons['stm']['horse']                       = array(
	'class' => 'horse',
	'tags'  => 'horse',
);
$icons['stm']['nokia_outline']               = array(
	'class' => 'nokia_outline',
	'tags'  => 'nokia_outline',
);
$icons['stm']['ppl_outline']                 = array(
	'class' => 'ppl_outline',
	'tags'  => 'ppl_outline',
);
$icons['stm']['sun_outline']                 = array(
	'class' => 'sun_outline',
	'tags'  => 'sun_outline',
);
$icons['stm']['branch']                      = array(
	'class' => 'branch',
	'tags'  => 'branch',
);
$icons['stm']['stm14_fax']                   = array(
	'class' => 'stm14_fax',
	'tags'  => 'stm14_fax',
);
$icons['stm']['stm14_bulb']                  = array(
	'class' => 'stm14_bulb',
	'tags'  => 'stm14_bulb',
);
$icons['stm']['stm14_calc']                  = array(
	'class' => 'stm14_calc',
	'tags'  => 'stm14_calc',
);
$icons['stm']['stm14_calendar']              = array(
	'class' => 'stm14_calendar',
	'tags'  => 'stm14_calendar',
);
$icons['stm']['stm14_country']               = array(
	'class' => 'stm14_country',
	'tags'  => 'stm14_country',
);
$icons['stm']['stm14_health']                = array(
	'class' => 'stm14_health',
	'tags'  => 'stm14_health',
);
$icons['stm']['stm14_left_arrow']            = array(
	'class' => 'stm14_left_arrow',
	'tags'  => 'stm14_left_arrow',
);
$icons['stm']['stm14_manufacturing']         = array(
	'class' => 'stm14_manufacturing',
	'tags'  => 'stm14_manufacturing',
);
$icons['stm']['stm14_office']                = array(
	'class' => 'stm14_office',
	'tags'  => 'stm14_office',
);
$icons['stm']['stm14_plane']                 = array(
	'class' => 'stm14_plane',
	'tags'  => 'stm14_plane',
);
$icons['stm']['stm14_public']                = array(
	'class' => 'stm14_public',
	'tags'  => 'stm14_public',
);
$icons['stm']['stm14_quote']                 = array(
	'class' => 'stm14_quote',
	'tags'  => 'stm14_quote',
);
$icons['stm']['stm14_right_arrow']           = array(
	'class' => 'stm14_right_arrow',
	'tags'  => 'stm14_right_arrow',
);
$icons['stm']['stm14_satellite']             = array(
	'class' => 'stm14_satellite',
	'tags'  => 'stm14_satellite',
);
$icons['stm']['stm14-arrow']                 = array(
	'class' => 'stm14-arrow',
	'tags'  => 'stm14-arrow',
);
$icons['stm']['stn14_home']                  = array(
	'class' => 'stn14_home',
	'tags'  => 'stn14_home',
);
$icons['stm']['cart_13']                     = array(
	'class' => 'cart_13',
	'tags'  => 'cart_13',
);
$icons['stm']['chip_13']                     = array(
	'class' => 'chip_13',
	'tags'  => 'chip_13',
);
$icons['stm']['env_13']                      = array(
	'class' => 'env_13',
	'tags'  => 'env_13',
);
$icons['stm']['horse_13']                    = array(
	'class' => 'horse_13',
	'tags'  => 'horse_13',
);
$icons['stm']['human_13']                    = array(
	'class' => 'human_13',
	'tags'  => 'human_13',
);
$icons['stm']['mail_13']                     = array(
	'class' => 'mail_13',
	'tags'  => 'mail_13',
);
$icons['stm']['phone_13_2']                  = array(
	'class' => 'phone_13_2',
	'tags'  => 'phone_13_2',
);
$icons['stm']['phone_13']                    = array(
	'class' => 'phone_13',
	'tags'  => 'phone_13',
);
$icons['stm']['pin_13']                      = array(
	'class' => 'pin_13',
	'tags'  => 'pin_13',
);
$icons['stm']['quote_13']                    = array(
	'class' => 'quote_13',
	'tags'  => 'quote_13',
);
$icons['stm']['quote2']                      = array(
	'class' => 'quote2',
	'tags'  => 'quote2',
);
$icons['stm']['pin-11']                      = array(
	'class' => 'pin-11',
	'tags'  => 'pin-11',
);
$icons['stm']['envelope-11']                 = array(
	'class' => 'envelope-11',
	'tags'  => 'envelope-11',
);
$icons['stm']['phone-11']                    = array(
	'class' => 'phone-11',
	'tags'  => 'phone-11',
);
$icons['stm']['quote8']                      = array(
	'class' => 'quote8',
	'tags'  => 'quote8',
);
$icons['stm']['shopping-cart8']              = array(
	'class' => 'shopping-cart8',
	'tags'  => 'shopping-cart8',
);
$icons['stm']['aim7']                        = array(
	'class' => 'aim7',
	'tags'  => 'aim7',
);
$icons['stm']['cup7']                        = array(
	'class' => 'cup7',
	'tags'  => 'cup7',
);
$icons['stm']['user7']                       = array(
	'class' => 'user7',
	'tags'  => 'user7',
);
$icons['stm']['docs7']                       = array(
	'class' => 'docs7',
	'tags'  => 'docs7',
);
$icons['stm']['bar-graph7']                  = array(
	'class' => 'bar-graph7',
	'tags'  => 'bar-graph7',
);
$icons['stm']['plant7']                      = array(
	'class' => 'plant7',
	'tags'  => 'plant7',
);
$icons['stm']['lorry6']                      = array(
	'class' => 'lorry6',
	'tags'  => 'lorry6',
);
$icons['stm']['lamp6']                       = array(
	'class' => 'lamp6',
	'tags'  => 'lamp6',
);
$icons['stm']['building6']                   = array(
	'class' => 'building6',
	'tags'  => 'building6',
);
$icons['stm']['cart6']                       = array(
	'class' => 'cart6',
	'tags'  => 'cart6',
);
$icons['stm']['line-graph6']                 = array(
	'class' => 'line-graph6',
	'tags'  => 'line-graph6',
);
$icons['stm']['plane6']                      = array(
	'class' => 'plane6',
	'tags'  => 'plane6',
);
$icons['stm']['user']                        = array(
	'class' => 'user',
	'tags'  => 'user',
);
$icons['stm']['crown']                       = array(
	'class' => 'crown',
	'tags'  => 'crown',
);
$icons['stm']['cup']                         = array(
	'class' => 'cup',
	'tags'  => 'cup',
);
$icons['stm']['polygon']                     = array(
	'class' => 'polygon',
	'tags'  => 'polygon',
);
$icons['stm']['person-globe']                = array(
	'class' => 'person-globe',
	'tags'  => 'person-globe',
);
$icons['stm']['head']                        = array(
	'class' => 'head',
	'tags'  => 'head',
);
$icons['stm']['arm-leaf']                    = array(
	'class' => 'arm-leaf',
	'tags'  => 'arm-leaf',
);
$icons['stm']['phone']                       = array(
	'class' => 'phone',
	'tags'  => 'phone',
);
$icons['stm']['phone6']                      = array(
	'class' => 'phone6',
	'tags'  => 'phone6',
);
$icons['stm']['clock6']                      = array(
	'class' => 'clock6',
	'tags'  => 'clock6',
);
$icons['stm']['pin6']                        = array(
	'class' => 'pin6',
	'tags'  => 'pin6',
);
$icons['stm']['clock']                       = array(
	'class' => 'clock',
	'tags'  => 'clock',
);
$icons['stm']['plus']                        = array(
	'class' => 'plus',
	'tags'  => 'plus',
);
$icons['stm']['earth']                       = array(
	'class' => 'earth',
	'tags'  => 'earth',
);
$icons['stm']['chart-refresh']               = array(
	'class' => 'chart-refresh',
	'tags'  => 'chart-refresh',
);
$icons['stm']['chart-monitor']               = array(
	'class' => 'chart-monitor',
	'tags'  => 'chart-monitor',
);
$icons['stm']['hexagon']                     = array(
	'class' => 'hexagon',
	'tags'  => 'hexagon',
);
$icons['stm']['metals']                      = array(
	'class' => 'metals',
	'tags'  => 'metals',
);
$icons['stm']['oil']                         = array(
	'class' => 'oil',
	'tags'  => 'oil',
);
$icons['stm']['target']                      = array(
	'class' => 'target',
	'tags'  => 'target',
);
$icons['stm']['rating_down']                 = array(
	'class' => 'rating_down',
	'tags'  => 'rating_down',
);
$icons['stm']['libra']                       = array(
	'class' => 'libra',
	'tags'  => 'libra',
);
$icons['stm']['diamond']                     = array(
	'class' => 'diamond',
	'tags'  => 'diamond',
);
$icons['stm']['idea']                        = array(
	'class' => 'idea',
	'tags'  => 'idea',
);
$icons['stm']['stats']                       = array(
	'class' => 'stats',
	'tags'  => 'stats',
);
$icons['stm']['badge']                       = array(
	'class' => 'badge',
	'tags'  => 'badge',
);
$icons['stm']['security']                    = array(
	'class' => 'security',
	'tags'  => 'security',
);
$icons['stm']['binoculars']                  = array(
	'class' => 'binoculars',
	'tags'  => 'binoculars',
);
$icons['stm']['mans']                        = array(
	'class' => 'mans',
	'tags'  => 'mans',
);
$icons['stm']['nokia']                       = array(
	'class' => 'nokia',
	'tags'  => 'nokia',
);
$icons['stm']['testimonials-new-2']          = array(
	'class' => 'testimonials-new-2',
	'tags'  => 'testimonials-new-2',
);
$icons['stm']['envelope']                    = array(
	'class' => 'envelope',
	'tags'  => 'envelope',
);
$icons['stm']['email']                       = array(
	'class' => 'email',
	'tags'  => 'email',
);
$icons['stm']['iphone']                      = array(
	'class' => 'iphone',
	'tags'  => 'iphone',
);
$icons['stm']['location-2']                  = array(
	'class' => 'location-2',
	'tags'  => 'location-2',
);
$icons['stm']['marker']                      = array(
	'class' => 'marker',
	'tags'  => 'marker',
);
$icons['stm']['check']                       = array(
	'class' => 'check',
	'tags'  => 'check',
);
$icons['stm']['truck']                       = array(
	'class' => 'truck',
	'tags'  => 'truck',
);
$icons['stm']['lamp']                        = array(
	'class' => 'lamp',
	'tags'  => 'lamp',
);
$icons['stm']['cart-2']                      = array(
	'class' => 'cart-2',
	'tags'  => 'cart-2',
);
$icons['stm']['cart']                        = array(
	'class' => 'cart',
	'tags'  => 'cart',
);
$icons['stm']['home']                        = array(
	'class' => 'home',
	'tags'  => 'home',
);
$icons['stm']['graph']                       = array(
	'class' => 'graph',
	'tags'  => 'graph',
);
$icons['stm']['airplane']                    = array(
	'class' => 'airplane',
	'tags'  => 'airplane',
);
$icons['stm']['compass']                     = array(
	'class' => 'compass',
	'tags'  => 'compass',
);
$icons['stm']['grid']                        = array(
	'class' => 'grid',
	'tags'  => 'grid',
);
$icons['stm']['rectangle']                   = array(
	'class' => 'rectangle',
	'tags'  => 'rectangle',
);
$icons['stm']['play-btn']                    = array(
	'class' => 'play-btn',
	'tags'  => 'play-btn',
);
$icons['stm']['zurich-certificate']          = array(
	'class' => 'zurich-certificate',
	'tags'  => 'zurich-certificate',
);
$icons['stm']['zurich-darts']                = array(
	'class' => 'zurich-darts',
	'tags'  => 'zurich-darts',
);
$icons['stm']['zurich-employed']             = array(
	'class' => 'zurich-employed',
	'tags'  => 'zurich-employed',
);
$icons['stm']['zurich-envelope']             = array(
	'class' => 'zurich-envelope',
	'tags'  => 'zurich-envelope',
);
$icons['stm']['zurich-growth']               = array(
	'class' => 'zurich-growth',
	'tags'  => 'zurich-growth',
);
$icons['stm']['zurich-hourse']               = array(
	'class' => 'zurich-hourse',
	'tags'  => 'zurich-hourse',
);
$icons['stm']['zurich-labore']               = array(
	'class' => 'zurich-labore',
	'tags'  => 'zurich-labore',
);
$icons['stm']['zurich-pin']                  = array(
	'class' => 'zurich-pin',
	'tags'  => 'zurich-pin',
);
$icons['stm']['zurich-like']                 = array(
	'class' => 'zurich-like',
	'tags'  => 'zurich-like',
);
$icons['stm']['zurich-microphone']           = array(
	'class' => 'zurich-microphone',
	'tags'  => 'zurich-microphone',
);
$icons['stm']['zurich-phone']                = array(
	'class' => 'zurich-phone',
	'tags'  => 'zurich-phone',
);
$icons['stm']['zurich-portfolio']            = array(
	'class' => 'zurich-portfolio',
	'tags'  => 'zurich-portfolio',
);
$icons['stm']['zurich-progress']             = array(
	'class' => 'zurich-progress',
	'tags'  => 'zurich-progress',
);
$icons['stm']['zurich-stamp']                = array(
	'class' => 'zurich-stamp',
	'tags'  => 'zurich-stamp',
);
$icons['stm']['mumbai_shape']                = array(
	'class' => 'mumbai_shape',
	'tags'  => 'mumbai_shape',
);
$icons['stm']['mumbai_security']             = array(
	'class' => 'mumbai_security',
	'tags'  => 'mumbai_security',
);
$icons['stm']['mumbai_people']               = array(
	'class' => 'mumbai_people',
	'tags'  => 'mumbai_people',
);
$icons['stm']['mumbai_graph']                = array(
	'class' => 'mumbai_graph',
	'tags'  => 'mumbai_graph',
);
$icons['stm']['mumbai_monitor']              = array(
	'class' => 'mumbai_monitor',
	'tags'  => 'mumbai_monitor',
);
$icons['stm']['mumbai_board']                = array(
	'class' => 'mumbai_board',
	'tags'  => 'mumbai_board',
);
$icons['stm']['mumbai_like']                 = array(
	'class' => 'mumbai_like',
	'tags'  => 'mumbai_like',
);
$icons['stm']['amsterdam-aim']               = array(
	'class' => 'amsterdam-aim',
	'tags'  => 'amsterdam-aim',
);
$icons['stm']['amsterdam-briefcase']         = array(
	'class' => 'amsterdam-briefcase',
	'tags'  => 'amsterdam-briefcase',
);
$icons['stm']['amsterdam-correct']           = array(
	'class' => 'amsterdam-correct',
	'tags'  => 'amsterdam-correct',
);
$icons['stm']['amsterdam-file']              = array(
	'class' => 'amsterdam-file',
	'tags'  => 'amsterdam-file',
);
$icons['stm']['amsterdam-lightning']         = array(
	'class' => 'amsterdam-lightning',
	'tags'  => 'amsterdam-lightning',
);
$icons['stm']['amsterdam-loupe']             = array(
	'class' => 'amsterdam-loupe',
	'tags'  => 'amsterdam-loupe',
);
$icons['stm']['amsterdam-profile']           = array(
	'class' => 'amsterdam-profile',
	'tags'  => 'amsterdam-profile',
);
$icons['stm']['amsterdam-presentation']      = array(
	'class' => 'amsterdam-presentation',
	'tags'  => 'amsterdam-presentation',
);
$icons['stm']['amsterdam-puzzle']            = array(
	'class' => 'amsterdam-puzzle',
	'tags'  => 'amsterdam-puzzle',
);
$icons['stm']['amsterdam-shield']            = array(
	'class' => 'amsterdam-shield',
	'tags'  => 'amsterdam-shield',
);
$icons['stm']['amsterdam-timer']             = array(
	'class' => 'amsterdam-timer',
	'tags'  => 'amsterdam-timer',
);
$icons['stm']['amsterdam-comment']           = array(
	'class' => 'amsterdam-comment',
	'tags'  => 'amsterdam-comment',
);
$icons['stm']['amsterdam-arrow']             = array(
	'class' => 'amsterdam-arrow',
	'tags'  => 'amsterdam-arrow',
);
$icons['stm']['davos_tech']                  = array(
	'class' => 'davos_tech',
	'tags'  => 'davos_tech',
);
$icons['stm']['davos_wi-fi']                 = array(
	'class' => 'davos_wi-fi',
	'tags'  => 'davos_wi-fi',
);
$icons['stm']['davos_livebuoy']              = array(
	'class' => 'davos_livebuoy',
	'tags'  => 'davos_livebuoy',
);
$icons['stm']['davos_heart']                 = array(
	'class' => 'davos_heart',
	'tags'  => 'davos_heart',
);
$icons['stm']['davos_folder']                = array(
	'class' => 'davos_folder',
	'tags'  => 'davos_folder',
);
$icons['stm']['davos_clock']                 = array(
	'class' => 'davos_clock',
	'tags'  => 'davos_clock',
);
$icons['stm']['davos_cart']                  = array(
	'class' => 'davos_cart',
	'tags'  => 'davos_cart',
);
$icons['stm']['denver-phone']                = array(
	'class' => 'denver-phone',
	'tags'  => 'denver-phone',
);
$icons['stm']['denver-envelope']             = array(
	'class' => 'denver-envelope',
	'tags'  => 'denver-envelope',
);
$icons['stm']['denver-oil']                  = array(
	'class' => 'denver-oil',
	'tags'  => 'denver-oil',
);
$icons['stm']['denver-mine']                 = array(
	'class' => 'denver-mine',
	'tags'  => 'denver-mine',
);
$icons['stm']['denver-energy']               = array(
	'class' => 'denver-energy',
	'tags'  => 'denver-energy',
);
$icons['stm']['denver-agriculture']          = array(
	'class' => 'denver-agriculture',
	'tags'  => 'denver-agriculture',
);
$icons['stm']['diamond']                     = array(
	'class' => 'diamond',
	'tags'  => 'diamond',
);
$icons['stm']['gear']                        = array(
	'class' => 'gear',
	'tags'  => 'gear',
);
$icons['stm']['credible']                    = array(
	'class' => 'credible',
	'tags'  => 'credible',
);
$icons['stm']['brief-bag']                   = array(
	'class' => 'brief-bag',
	'tags'  => 'brief-bag',
);
$icons['stm']['ship']                        = array(
	'class' => 'ship',
	'tags'  => 'ship',
);
$icons['stm']['schedule']                    = array(
	'class' => 'schedule',
	'tags'  => 'schedule',
);
$icons['stm']['lamp1']                       = array(
	'class' => 'lamp1',
	'tags'  => 'lamp1',
);
$icons['stm']['earth1']                      = array(
	'class' => 'earth1',
	'tags'  => 'earth1',
);
$icons['stm']['monetary_purpose']            = array(
	'class' => 'monetary_purpose',
	'tags'  => 'monetary_purpose',
);
$icons['stm']['money_flower']                = array(
	'class' => 'money_flower',
	'tags'  => 'money_flower',
);
$icons['stm']['rocket']                      = array(
	'class' => 'rocket',
	'tags'  => 'rocket',
);
$icons['stm']['fortress']                    = array(
	'class' => 'fortress',
	'tags'  => 'fortress',
);
$icons['stm']['brief-bag-2']                 = array(
	'class' => 'brief-bag-2',
	'tags'  => 'brief-bag-2',
);
$icons['stm']['employed']                    = array(
	'class' => 'employed',
	'tags'  => 'employed',
);
$icons['stm']['stamp']                       = array(
	'class' => 'stamp',
	'tags'  => 'stamp',
);
$icons['stm']['like']                        = array(
	'class' => 'like',
	'tags'  => 'like',
);
$icons['stm']['shield_flat']                 = array(
	'class' => 'shield_flat',
	'tags'  => 'shield_flat',
);
$icons['stm']['delhi-staff']                 = array(
	'class' => 'delhi-staff',
	'tags'  => 'delhi-staff',
);
$icons['stm']['delhi-safety']                = array(
	'class' => 'delhi-safety',
	'tags'  => 'delhi-safety',
);
$icons['stm']['delhi-medal']                 = array(
	'class' => 'delhi-medal',
	'tags'  => 'delhi-medal',
);
$icons['stm']['delhi-lamp']                  = array(
	'class' => 'delhi-lamp',
	'tags'  => 'delhi-lamp',
);
$icons['stm']['delhi-horse']                 = array(
	'class' => 'delhi-horse',
	'tags'  => 'delhi-horse',
);
$icons['stm']['delhi-heands']                = array(
	'class' => 'delhi-heands',
	'tags'  => 'delhi-heands',
);
$icons['stm']['delhi-eye']                   = array(
	'class' => 'delhi-eye',
	'tags'  => 'delhi-eye',
);
$icons['stm']['delhi-diamond']               = array(
	'class' => 'delhi-diamond',
	'tags'  => 'delhi-diamond',
);
$icons['stm']['delhi-chevron-left']          = array(
	'class' => 'delhi-chevron-left',
	'tags'  => 'delhi-chevron-left',
);
$icons['stm']['delhi-chevron-right']         = array(
	'class' => 'delhi-chevron-right',
	'tags'  => 'delhi-chevron-right',
);
$icons['stm']['atlanta-heading-left-shape']  = array(
	'class' => 'atlanta-heading-left-shape',
	'tags'  => 'atlanta-heading-left-shape',
);
$icons['stm']['atlanta-heading-right-shape'] = array(
	'class' => 'atlanta-heading-right-shape',
	'tags'  => 'atlanta-heading-right-shape',
);
$icons['stm']['atlanta-user']                = array(
	'class' => 'atlanta-user',
	'tags'  => 'atlanta-user',
);
$icons['stm']['atlanta-phone']               = array(
	'class' => 'atlanta-phone',
	'tags'  => 'atlanta-phone',
);
$icons['stm']['atlanta-megaphone']           = array(
	'class' => 'atlanta-megaphone',
	'tags'  => 'atlanta-megaphone',
);
$icons['stm']['atlanta-map-marker']          = array(
	'class' => 'atlanta-map-marker',
	'tags'  => 'atlanta-map-marker',
);
$icons['stm']['atlanta-mail']                = array(
	'class' => 'atlanta-mail',
	'tags'  => 'atlanta-mail',
);
$icons['stm']['atlanta-light']               = array(
	'class' => 'atlanta-light',
	'tags'  => 'atlanta-light',
);
$icons['stm']['atlanta-cup']                 = array(
	'class' => 'atlanta-cup',
	'tags'  => 'atlanta-cup',
);
$icons['stm']['atlanta-keyboard']            = array(
	'class' => 'atlanta-keyboard',
	'tags'  => 'atlanta-keyboard',
);
$icons['stm']['atlanta-pizza']               = array(
	'class' => 'atlanta-pizza',
	'tags'  => 'atlanta-pizza',
);
$icons['stm']['atlanta-calc']                = array(
	'class' => 'atlanta-calc',
	'tags'  => 'atlanta-calc',
);
$icons['stm']['atlanta-briefcase']           = array(
	'class' => 'atlanta-briefcase',
	'tags'  => 'atlanta-briefcase',
);
$icons['stm']['atlanta-bitcoin']             = array(
	'class' => 'atlanta-bitcoin',
	'tags'  => 'atlanta-bitcoin',
);
$icons['stm']['atlanta-shopping-cart']       = array(
	'class' => 'atlanta-shopping-cart',
	'tags'  => 'atlanta-shopping-cart',
);
$icons['stm']['kuala-dermatology']           = array(
	'class' => 'kuala-dermatology',
	'tags'  => 'kuala-dermatology',
);
$icons['stm']['kuala-consulting']            = array(
	'class' => 'kuala-consulting',
	'tags'  => 'kuala-consulting',
);
$icons['stm']['kuala-protection']            = array(
	'class' => 'kuala-protection',
	'tags'  => 'kuala-protection',
);
$icons['stm']['kuala-orthopedics']           = array(
	'class' => 'kuala-orthopedics',
	'tags'  => 'kuala-orthopedics',
);
$icons['stm']['kuala-mental-health']         = array(
	'class' => 'kuala-mental-health',
	'tags'  => 'kuala-mental-health',
);
$icons['stm']['kuala-gynecological']         = array(
	'class' => 'kuala-gynecological',
	'tags'  => 'kuala-gynecological',
);
$icons['stm']['kuala-circle']                = array(
	'class' => 'kuala-circle',
	'tags'  => 'kuala-circle',
);
$icons['stm']['kuala-shape']                 = array(
	'class' => 'kuala-shape',
	'tags'  => 'kuala-shape',
);
$icons['stm']['kuala-flower-1']              = array(
	'class' => 'kuala-flower-1',
	'tags'  => 'kuala-flower-1',
);
$icons['stm']['kuala-flower-2']              = array(
	'class' => 'kuala-flower-2',
	'tags'  => 'kuala-flower-2',
);
$icons['stm']['kuala-flower-3']              = array(
	'class' => 'kuala-flower-3',
	'tags'  => 'kuala-flower-3',
);
$icons['stm']['kuala-flower-4']              = array(
	'class' => 'kuala-flower-4',
	'tags'  => 'kuala-flower-4',
);
$icons['stm']['kuala-flower-4']              = array(
	'class' => 'kuala-flower-4',
	'tags'  => 'kuala-flower-4',
);
$icons['stm']['kuala-flower-5']              = array(
	'class' => 'kuala-flower-5',
	'tags'  => 'kuala-flower-5',
);
